#ifndef EjecutarEstadoActual_h
#define EjecutarEstadoActual_h

    #include <Arduino.h>

#include "Variables.h"
#include "Estados.h"
#include "InterpretarGcode.h"
#include "MoverEjes.h"

void ejecutarEstadoActual();

#endif