#ifndef MensajeBienvenida_h
#define MensajeBienvenida_h
   
    #include <Arduino.h>
    
void MensajeBienvenida();

#endif