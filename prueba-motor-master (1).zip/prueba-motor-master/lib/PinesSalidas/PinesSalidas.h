#ifndef PinesSalidas_h
   #define PinesSalidas_h
    #include <Arduino.h>

#include "Variables.h"

void pines();

#endif