#include "EstadosG.h"
State2 EstadoG = G0;