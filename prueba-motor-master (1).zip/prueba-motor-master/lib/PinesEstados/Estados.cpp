#include "Estados.h"
State Estados = ESPERA;